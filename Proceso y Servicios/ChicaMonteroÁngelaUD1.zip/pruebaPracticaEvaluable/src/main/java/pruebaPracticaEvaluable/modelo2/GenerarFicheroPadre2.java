package pruebaPracticaEvaluable.modelo2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class GenerarFicheroPadre2 {
	
	//padre
	
	private static final String rutaFicheroJava = "src\\main\\java\\pruebaPracticaEvaluable\\modelo2\\LeerVariablesAmbientales2.java";
	private static final String directorioGenerarClases = "target\\classes";

	public static void main(String[] args) {
		
		GenerarFicheroPadre2 lanzadorPadre = new GenerarFicheroPadre2();
		
		String[] filtro = { "TEMPERATURA", "HUMEDAD", "PRESION"};
		
		String ficheroPedidoProvincias = "src\\main\\resources\\lecturas.txt";
		
		lanzadorPadre.compilaProceso();

		//int totalDatos = 0;

		System.out.println("--- Proceso Padre: Resumen Resultados ---");
		
		// por cada provincia de la lista lanza un proceso que ejecuta las funciones del hijo
		for (String nombreProv : filtro) {

			lanzadorPadre.ejecutaProceso(ficheroPedidoProvincias, nombreProv);

		}

	//System.out.println("Total pedidos: " + totalDatos);

	}

	
	public void compilaProceso() {

		String[] comando = { "javac", "-d", directorioGenerarClases, rutaFicheroJava };
		ProcessBuilder pb = new ProcessBuilder(comando);

		try {
			// para la comunicacion entre proceso padre e hijo
			pb.redirectErrorStream(true);
			pb.inheritIO();
			Process p1 = pb.start();
			int exit = p1.waitFor();

		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public int ejecutaProceso(String ruta, String prov) {

		int numero = 0;
		String[] comando1 = { "java", "-cp", directorioGenerarClases, rutaFicheroJava, ruta, prov };

		ProcessBuilder pb = new ProcessBuilder(comando1);

		try {
			// esto se cambia por el buffer
			/*
			 * pb.redirectErrorStream(true); pb.inheritIO();
			 */
			Process p1 = pb.start();
			/*
			 * int exit = p1.waitFor(); System.out.println(exit);
			 */

			// lee el padre lo que diga el hijo por consola
			BufferedReader reader = new BufferedReader(new InputStreamReader(p1.getInputStream()));

			// porsi ocurre un error en el hijo el padre pueda leerlo
			BufferedReader stdError = new BufferedReader(new InputStreamReader(p1.getErrorStream()));

			String linea = reader.readLine();
			// porsi guarda mas de una linea
			while (linea != null) {
				System.out.println(linea);
				String[] porpuntos = linea.split(":");
				linea = reader.readLine();
				//coge la posicion donde esta el numero
				//numero = Integer.parseInt(porpuntos[1]);
			}


		} catch (IOException e) {
			e.printStackTrace();

		}
		return numero;

	}

}
